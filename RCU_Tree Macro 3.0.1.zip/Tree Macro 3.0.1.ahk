#NoEnv
#SingleInstance Force
#Include Modules\Routes.ahk
#Include Modules\TreeChopCounter.ahk

if not A_IsAdmin
{
    Run *RunAs "%A_ScriptFullPath%"
    ExitApp
}

SendMode Event
SetBatchLines, -1
SetMouseDelay, -1
SetKeyDelay, -1, -1

CoordMode, Mouse, Window
CoordMode, Pixel, Screen

global STOP := false
global PAUSED := false
global CURRENT_ROUTE := "Spawn"
global robloxExe := "RobloxPlayerBeta.exe"
global spawnBoxVisible := false

; Window bounds - will be set during setup
global windowWidth := 1320
global windowHeight := 1047

; ============================================================
; MOUNT HOVERBOARD HELPER (defined early)
; ============================================================
MountHoverboard() {
    SendEvent, {q Down}
    Sleep, 400
    SendEvent, {q Up}
    Sleep, 300
}

; ============================================================
; DRAW OUTLINE HELPERS
; ============================================================
DrawBox(name, x, y, w, h, color) {
    WinGetPos, winX, winY,,, ahk_exe RobloxPlayerBeta.exe
    
    bx := winX + x
    by := winY + y
    border := 2
    
    n1 := name . "T"
    Gui, %n1%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n1%:Color, %color%
    Gui, %n1%:Show, x%bx% y%by% w%w% h%border% NoActivate
    
    bottomY := by + h - border
    n2 := name . "B"
    Gui, %n2%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n2%:Color, %color%
    Gui, %n2%:Show, x%bx% y%bottomY% w%w% h%border% NoActivate
    
    n3 := name . "L"
    Gui, %n3%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n3%:Color, %color%
    Gui, %n3%:Show, x%bx% y%by% w%border% h%h% NoActivate
    
    rightX := bx + w - border
    n4 := name . "R"
    Gui, %n4%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n4%:Color, %color%
    Gui, %n4%:Show, x%rightX% y%by% w%border% h%h% NoActivate
}

HideBox(name) {
    n1 := name . "T"
    n2 := name . "B"
    n3 := name . "L"
    n4 := name . "R"
    Gui, %n1%:Destroy
    Gui, %n2%:Destroy
    Gui, %n3%:Destroy
    Gui, %n4%:Destroy
}

; ============================================================
; SAFE CLICK - For important UI clicks (rewards, teleport)
; ============================================================
SafeClick(x, y, clicks := 1) {
    global robloxExe, windowWidth, windowHeight
    
    if (x < 10)
        x := 10
    if (x > windowWidth - 10)
        x := windowWidth - 10
    if (y < 10)
        y := 10
    if (y > windowHeight - 10)
        y := windowHeight - 10
    
    WinActivate, ahk_exe %robloxExe%
    WinWaitActive, ahk_exe %robloxExe%,, 0.5
    
    IfWinNotActive, ahk_exe %robloxExe%
    {
        WinActivate, ahk_exe %robloxExe%
        Sleep, 100
    }
    
    Click, %x%, %y%, %clicks%
    return true
}

; ============================================================
; FAST CLICK - For tree chopping (no activation overhead)
; ============================================================
FastClick(x, y, clicks := 1) {
    global windowWidth, windowHeight
    
    if (x < 10)
        x := 10
    if (x > windowWidth - 10)
        x := windowWidth - 10
    if (y < 10)
        y := 10
    if (y > windowHeight - 10)
        y := windowHeight - 10
    
    Click, %x%, %y%, %clicks%
    return true
}

; ============================================================
; F1 = START FARMING (uses CURRENT_ROUTE)
; ============================================================
F1::
{
    global StartTime
    StartTime := A_TickCount
    SetTimer, UpdateTreeChopCounterGUI, 1000   ; Calls module's function every second
    ShowTreeChopCounters()

    ; --- ONE-TIME SETUP ---
    WinActivate, ahk_exe %robloxExe%
    WinWaitActive, ahk_exe %robloxExe%,, 2
    
    WinMove, ahk_exe %robloxExe%,, 274, 0, 1320, 1047
    Sleep, 500
    
    WinActivate, ahk_exe %robloxExe%
    WinWaitActive, ahk_exe %robloxExe%,, 2
    Sleep, 500

    ; Click to ensure focus
    Click, 660, 500
    Sleep, 300

    GoSub, AlignMushroom

    ; --- WALK LEFT UNTIL SPAWN ANCHOR FOUND ---
    GoSub, FindSpawnAnchor

    ; --- CAMERA ROTATION / ZOOM OUT ---
    GoSub, CameraSetup

	Sleep, 500

	
	Send, {S Down}
    Sleep, 300
    Send, {S Up}
    Sleep, 500
	
	ChopTreeFast(890, 600, 470, 850)
	Sleep, 1000

    ; ============================================================
    ; MAIN LOOP — mount, run selected route, repeat
    ; ============================================================
    Loop
    {
        if (STOP)
            break

        ; --- RUN SELECTED ROUTE ---
        if (CURRENT_ROUTE = "Spawn")
            Route_Spawn()
        else if (CURRENT_ROUTE = "Desert")
            Route_Desert()
        else if (CURRENT_ROUTE = "Nuclear")
            Route_Nuclear()
        else if (CURRENT_ROUTE = "Atlantis")
            Route_Atlantis()
        else if (CURRENT_ROUTE = "Kingdom")
            Route_Kingdom()
        else if (CURRENT_ROUTE = "Cave")
            Route_Cave()
        else if (CURRENT_ROUTE = "Volcano")
            Route_Volcano()
        else if (CURRENT_ROUTE = "Heaven")
            Route_Heaven()
        else if (CURRENT_ROUTE = "Magic")
            Route_Magic()
        else if (CURRENT_ROUTE = "Circus")
            Route_Circus()
        else if (CURRENT_ROUTE = "Jungle")
            Route_Jungle()
        else if (CURRENT_ROUTE = "Steampunk")
            Route_Steampunk()
        else if (CURRENT_ROUTE = "Sakura")
            Route_Sakura()

        if (STOP)
            break

    }
    return
}

; ============================================================
; F2 = EMERGENCY STOP
; ============================================================
F2::
{
    ; Save tree counter + time
    global TreeChopCount, StartTime
    EndTime := A_TickCount
    Elapsed := (StartTime) ? Floor((EndTime - StartTime) / 1000) : 0
    FormatString := "Trees: " . TreeChopCount . "`nTime: " . Elapsed . " sec"
    
    logsDir := A_ScriptDir . "\Logs"
    if !FileExist(logsDir)
        FileCreateDir, %logsDir%
    resultsPath := logsDir . "\TreeChopResults.txt"
    FileAppend, %FormatString%`n, %resultsPath%

    ; Stop timer
    SetTimer, UpdateTreeChopCounterGUI, Off

    ; Hide UI/counter
    HideTreeChopCounters()

    STOP := true
    HideBox("Spawn")
    HideBox("Ret")
    spawnBoxVisible := false
    Send, {LButton up}{RButton up}{w up}{a up}{s up}{d up}{q up}{o up}{t up}{1 up}{Left up}

    ; Exit the app
    ExitApp
    return
}

; ============================================================
; F3 = OPEN ROUTE SELECTOR
; ============================================================
F3::
{
    Gui, Destroy
    Gui, +AlwaysOnTop
    Gui, Font, s10
    Gui, Add, Text, , Select Farming Area:
    Gui, Add, ListBox, vSelectedRoute w200 h250, Spawn|Desert|Nuclear|Atlantis|Kingdom|Cave|Volcano|Heaven|Magic|Circus|Jungle|Steampunk|Sakura
    Gui, Add, Button, gSetRoute w200, Start This Route
    Gui, Show, , Route Selector
    return

    SetRoute:
        Gui, Submit, NoHide
        CURRENT_ROUTE := SelectedRoute
        Gui, Destroy
        ToolTip, Route set to: %CURRENT_ROUTE%
        Sleep, 1500
        ToolTip
    return

    GuiClose:
        Gui, Destroy
    return
}

; F4::
; ShowTreeChopCounters()

; ============================================================
; CAMERA SETUP - Rotation / Zoom Out
; ============================================================
CameraSetup:
    Send, {o Down}
    Sleep, 500
    Send, {o Up}
    Sleep, 200

    Click, 810, 635, 0
    Sleep, 10
    Send, {LButton Down}
    Sleep, 10
    Click, 1020, 826, 0
    Sleep, 10
    Send, {LButton Up}
    Sleep, 10

    Click, 506, 464, 0
    Sleep, 10
    Click, 500, 250, 0
    Sleep, 10

    Send, {RButton Down}
    Sleep, 10
    Click, 514, 708, 0
    Sleep, 10
    Send, {RButton Up}
    Sleep, 10

    Send, {1 Down}
    Sleep, 50
    Send, {1 Up}
    Sleep, 500
return

; ============================================================
; MUSHROOM ALIGNMENT
; ============================================================
AlignMushroom:
    mushroomFound := false

    ; Check for bright red arrow
    PixelSearch, px, py, 658, 181, 815, 281, 0xFF1C00, 96, Fast RGB
    if (ErrorLevel = 0)
        mushroomFound := true
    
    ; Check for dusty tan arrow
    if (!mushroomFound)
    {
        PixelSearch, px, py, 658, 181, 815, 281, 0xF9CA8E, 30, Fast RGB
        if (ErrorLevel = 0)
            mushroomFound := true
    }

    ; Check for orange arrow
    if (!mushroomFound)
    {
        PixelSearch, px, py, 658, 181, 815, 281, 0xF47465, 30, Fast RGB
        if (ErrorLevel = 0)
            mushroomFound := true
    }

    if (!mushroomFound)
    {
        ALT_ROUTE := true

        Send, {Left Down}
        Sleep, 150
        Send, {Left Up}
        Sleep, 80

        Loop, 25 {
            anomalyFound := false
            Loop, Files, %A_ScriptDir%\Resources\*Anomaly_10x10.*
            {
                ImageSearch, mx, my, 884, 330, 964, 400, *50 %A_LoopFileFullPath%
                if (ErrorLevel = 0)
                {
                    anomalyFound := true
                    break
                }
            }
            if (anomalyFound)
            {
                Send, {Left Down}
                Sleep, 10
                Send, {Left Up}
                Sleep, 60
                break
            }

            Send, {Left Down}
            Sleep, 10
            Send, {Left Up}
            Sleep, 60
        }
        Send, {Left Up}
        Sleep, 10
    }
    else
    {
        ALT_ROUTE := false
    }
return

; ============================================================
; FIND SPAWN ANCHOR - Walk left continuously until detected
; ============================================================
FindSpawnAnchor:
    ; Show search area outline - GREEN
    DrawBox("Spawn", 308, 421, 366 - 308, 569 - 421, "00FF00")
    spawnBoxVisible := true
    
    ; Switch to Window coords for ImageSearch
    CoordMode, Pixel, Window
    
    Send, {a Down}
    
    Loop
    {
        if (STOP)
        {
            Send, {a Up}
            break
        }
        
        ; Check for any Spawn*.png in Resources folder
        anchorFound := false
        Loop, Files, %A_ScriptDir%\Resources\*Spawn*.png
        {
            ImageSearch, ix, iy, 308, 421, 366, 569, *30 %A_LoopFileFullPath%
            if (ErrorLevel = 0)
            {
                anchorFound := true
                break
            }
        }
        
        if (anchorFound)
        {
            Send, {a Up}
            Sleep, 300
            
            ; Mount hoverboard
            Send, {q Down}
            Sleep, 400
            Send, {q Up}
            Sleep, 300
            
			Send, {A Down}
			Sleep, 100
			Send, {A Up}
			Sleep, 500
			
            ; Walk down
            Send, {s Down}
            Sleep, 1000
            Send, {s Up}
            
            ; Wait for momentum to stop
            Sleep, 300
            
            ; Restore Screen coords
            CoordMode, Pixel, Screen
            
            return
        }
        
        Sleep, 30
    }
    
    ; Restore Screen coords
    CoordMode, Pixel, Screen
return

; ============================================================
; FIND RETURN ANCHOR - While walking W, detect Tele*.png
; ============================================================
FindReturnAnchor:
    ; Show search area outline - GREEN
    DrawBox("Ret", 545, 207, 845 - 545, 251 - 207, "00FF00")

    ; Switch to Window coords for ImageSearch
    CoordMode, Pixel, Window

    Loop
    {
        if (STOP)
        {
            Send, {w Up}
            break
        }

        ; Check for any Tele*.png in Resources folder
        returnAnchorFound := false
        Loop, Files, %A_ScriptDir%\Resources\*Tele*.png
        {
            ImageSearch, ix, iy, 545, 207, 845, 251, *30 %A_LoopFileFullPath%
            if (ErrorLevel = 0)
            {
                returnAnchorFound := true
                break
            }
        }

        if (returnAnchorFound)
        {
            Send, {w Up}
            Sleep, 300

            ; Hide the return anchor box
            HideBox("Ret")

            ; Restore Screen coords
            CoordMode, Pixel, Screen
            return
        }

        Sleep, 30
    }

    ; Restore Screen coords
    CoordMode, Pixel, Screen
return

; ============================================================
; CHECK REWARDS
; ============================================================
CheckRewards:
    PixelSearch, rx, ry, 1275, 456, 1298, 480, 0xFF444F, 15, Fast RGB

    if (ErrorLevel = 0)
    {
        SafeClick(1212, 475)
        Sleep, 500

        SafeClick(425, 414)
        Sleep, 200
        SafeClick(578, 414)
        Sleep, 200
        SafeClick(726, 414)
        Sleep, 200
        SafeClick(885, 447)
        Sleep, 200

        SafeClick(429, 525)
        Sleep, 200
        SafeClick(577, 525)
        Sleep, 200
        SafeClick(727, 525)
        Sleep, 200
        SafeClick(877, 525)
        Sleep, 200

        SafeClick(425, 630)
        Sleep, 200
        SafeClick(577, 630)
        Sleep, 200
        SafeClick(727, 630)
        Sleep, 200
        SafeClick(877, 630)
        Sleep, 500

        SafeClick(955, 308)
        Sleep, 100
        SafeClick(955, 308)
        Sleep, 100
        SafeClick(955, 308)
        Sleep, 300
    }
return

; ============================================================
; HELPER FUNCTIONS (ChopTreeX, ChopTree, ChopTreeFast, etc.)
; ============================================================

ChopTreeX(x1, y1, x2, y2, steps := 10, skipMount := false, skipSpecial := false) {
    global STOP

    IncrementTreeChopCounter()

    ; First stroke: top-left to bottom-right
    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        SendInput, {Click %x% %y%}
    }

    ; Second stroke: top-right to bottom-left
    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x2 + t * (x1 - x2))
        y := Round(y1 + t * (y2 - y1))
        SendInput, {Click %x% %y%}
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    if (!skipSpecial)
    {
        centerX := Round((x1 + x2) / 2)
        centerY := Round((y1 + y2) / 2)
        needsExtraChop := false

        if (IsGoldTree(centerX, centerY))
            needsExtraChop := true
        else if (IsRainbowTree(centerX, centerY))
            needsExtraChop := true

        if (needsExtraChop)
        {
            Loop, %steps% {
                if (STOP)
                    return
                t := (A_Index - 1) / (steps - 1)
                x := Round(x1 + t * (x2 - x1))
                y := Round(y1 + t * (y2 - y1))
                SendInput, {Click %x% %y%}
            }
            Loop, %steps% {
                if (STOP)
                    return
                t := (A_Index - 1) / (steps - 1)
                x := Round(x2 + t * (x1 - x2))
                y := Round(y1 + t * (y2 - y1))
                SendInput, {Click %x% %y%}
            }

            blueFound := WaitForBluePixel(800)
            if (blueFound)
            {
                WaitForBlueGone(6000)
                Sleep, 50
            }
        }
    }
    
    if (!skipMount)
        MountHoverboard()
}

ChopTree(x1, y1, x2, y2, steps := 12) {
    global STOP

    IncrementTreeChopCounter()

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 15
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    centerX := Round((x1 + x2) / 2)
    centerY := Round((y1 + y2) / 2)
    needsExtraChop := false

    if (IsGoldTree(centerX, centerY))
        needsExtraChop := true
    else if (IsRainbowTree(centerX, centerY))
        needsExtraChop := true

    if (needsExtraChop)
    {
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x1 + t * (x2 - x1))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 10
        }

        blueFound := WaitForBluePixel(800)
        if (blueFound)
        {
            WaitForBlueGone(6000)
            Sleep, 50
        }
    }
    
    MountHoverboard()
}

ChopTreeFast(x1, y1, x2, y2, steps := 8) {
    global STOP

    IncrementTreeChopCounter()

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 5
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    centerX := Round((x1 + x2) / 2)
    centerY := Round((y1 + y2) / 2)
    needsExtraChop := false

    if (IsGoldTree(centerX, centerY))
        needsExtraChop := true
    else if (IsRainbowTree(centerX, centerY))
        needsExtraChop := true

    if (needsExtraChop)
    {
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x1 + t * (x2 - x1))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 3
        }

        blueFound := WaitForBluePixel(800)
        if (blueFound)
        {
            WaitForBlueGone(6000)
            Sleep, 50
        }
    }
    
    MountHoverboard()
}

WaitForBluePixel(timeoutMs) {
    global STOP
    start := A_TickCount
    while (!STOP && (A_TickCount - start) < timeoutMs) {
        PixelSearch, fx, fy, 390, 702, 415, 736, 0x32AEFD, 15, Fast RGB
        if (ErrorLevel = 0)
            return true
        Sleep, 20
    }
    return false
}

WaitForBlueGone(timeoutMs) {
    global STOP
    start := A_TickCount
    while (!STOP && (A_TickCount - start) < timeoutMs) {
        PixelSearch, fx, fy, 390, 702, 415, 736, 0x32AEFD, 15, Fast RGB
        if (ErrorLevel != 0)
            return true
        Sleep, 50
    }
    return false
}

IsGoldTree(x, y) {
    PixelGetColor, c, %x%, %y%, RGB
    r := (c >> 16) & 0xFF
    g := (c >> 8) & 0xFF
    b := c & 0xFF

    if (r > 200 && g > 200 && b < 120)
        return true
    return false
}

IsRainbowTree(x, y, samples := 3, threshold := 2) {
    colors := []
    Loop, %samples% {
        PixelGetColor, c, %x%, %y%, RGB
        colors.Push(c)
        Sleep, 60
    }

    changes := 0
    Loop, % colors.Length() - 1 {
        c1 := colors[A_Index]
        c2 := colors[A_Index + 1]

        r1 := (c1 >> 16) & 0xFF, g1 := (c1 >> 8) & 0xFF, b1 := c1 & 0xFF
        r2 := (c2 >> 16) & 0xFF, g2 := (c2 >> 8) & 0xFF, b2 := c2 & 0xFF

        diff := Abs(r1 - r2) + Abs(g1 - g2) + Abs(b1 - b2)
        if (diff > 80)
            changes++
    }

    return (changes >= threshold)
}

	SpawnTeleportLoop:
	Loop
		{
		SendEvent, t
		Sleep, 1500

		; Click Spawn directly (no search needed)
		Click, 813, 502
		Sleep, 200
		Click, 813, 502
		Sleep, 200

		; Click teleport button
		Click, 812, 490
		Sleep, 100
		Click, 812, 490
		Sleep, 100
		Click, 812, 491
		Sleep, 100
		Click, 812, 491
		Sleep, 100
		Click, 812, 490
		Sleep, 2000
	Return	
}