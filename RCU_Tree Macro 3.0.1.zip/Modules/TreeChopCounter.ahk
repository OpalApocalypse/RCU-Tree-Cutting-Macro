global TreeChopCount := 0
global StartTime := 0
global ElapsedTime := 0
global GuiTreeChopCounterBuilt := false
global CounterText1
global CounterText2

; Builds the GUI counter window the first time
BuildTreeChopCounterGUI() {
    if (GuiTreeChopCounterBuilt)
        return
    Gui, TreeChopCounter:+AlwaysOnTop -Caption +ToolWindow +LastFound
    Gui, TreeChopCounter:Color, 000000
    Gui, TreeChopCounter:Font, s10 bold, Segoe UI       ; Slightly larger font for title
    Gui, TreeChopCounter:Add, Text, w190 Center cFFD700, Opal's NONG Tree Macro
    Gui, TreeChopCounter:Font, s10 bold, Consolas       ; Switch to monospaced for counters
    treesString := "Trees: " . TreeChopCount
    timeString := "Time: " . ElapsedTime . " sec"
    Gui, TreeChopCounter:Add, Text, vCounterText1 w190 Center cFFFFFF, %treesString%
    Gui, TreeChopCounter:Add, Text, vCounterText2 w190 Center cFFFFFF, %timeString%
    Gui, TreeChopCounter:Show, x282 y100 w220 h90 NoActivate, TreeChopCounter  ; Increased height for title
    WinSet, Transparent, 150
    GuiTreeChopCounterBuilt := true
}

; Updates the values in the GUI counter window
ShowTreeChopCounters() {
    global StartTime, ElapsedTime, TreeChopCount
    if (StartTime)
        ElapsedTime := Floor((A_TickCount - StartTime) / 1000)
    else
        ElapsedTime := 0
    treesString := "Trees: " . TreeChopCount
    timeString := "Time: " . ElapsedTime . " sec"
    BuildTreeChopCounterGUI()
    GuiControl, TreeChopCounter:, CounterText1, %treesString%
    GuiControl, TreeChopCounter:, CounterText2, %timeString%
}

; Timer function to call every second with SetTimer (from your main script)
UpdateTreeChopCounterGUI() {
    ShowTreeChopCounters()
}

IncrementTreeChopCounter() {
    global TreeChopCount
    TreeChopCount += 1
    ShowTreeChopCounters()
}

ResetTreeChopCounters() {
    global TreeChopCount
    global GuiTreeChopCounterBuilt
    TreeChopCount := 0
    ShowTreeChopCounters()
}

HideTreeChopCounters() {
    Gui, TreeChopCounter:Destroy
    GuiTreeChopCounterBuilt := false
}