; ============================================================
; ALIGNMENT AND ANCHOR FUNCTIONS
; ============================================================

#Include Modules\TreeFunctions.ahk

AlignMushroom:
    mushroomFound := false

    ; Check for bright red arrow
    PixelSearch, px, py, 658, 181, 815, 281, 0xFF1C00, 96, Fast RGB
    if (ErrorLevel = 0)
        mushroomFound := true

    ; Check for dusty tan arrow
    if (!mushroomFound)
    {
        PixelSearch, px, py, 658, 181, 815, 281, 0xF9CA8E, 30, Fast RGB
        if (ErrorLevel = 0)
            mushroomFound := true
    }

    ; Check for orange arrow
    if (!mushroomFound)
    {
        PixelSearch, px, py, 658, 181, 815, 281, 0xF47465, 30, Fast RGB
        if (ErrorLevel = 0)
            mushroomFound := true
    }

    if (!mushroomFound)
    {
        ALT_ROUTE := true
        Send, {Left Down}
        Sleep, 150
        Send, {Left Up}
        Sleep, 80

        Loop, 25 {
            anomalyFound := false
            Loop, Files, %A_ScriptDir%\Resources\*Anomaly_10x10.*
            {
                ImageSearch, mx, my, 884, 330, 964, 400, *50 %A_LoopFileFullPath%
                if (ErrorLevel = 0)
                {
                    anomalyFound := true
                    break
                }
            }
            if (anomalyFound)
            {
                Send, {Left Down}
                Sleep, 10
                Send, {Left Up}
                Sleep, 60
                break
            }
            Send, {Left Down}
            Sleep, 10
            Send, {Left Up}
            Sleep, 60
        }
        Send, {Left Up}
        Sleep, 10
    }
    else
    {
        ALT_ROUTE := false
    }
return

FindSpawnAnchor:
    CoordMode, Pixel, Window

    Send, {a Down}

    Loop
    {
        if (STOP)
        {
            Send, {a Up}
            break
        }

        ; Check for any Spawn*.png in Resources folder
        anchorFound := false
        Loop, Files, %A_ScriptDir%\Resources\*Spawn*.png
        {
            ImageSearch, ix, iy, 268, 421, 326, 569, *30 %A_LoopFileFullPath%
            if (ErrorLevel = 0)
            {
                anchorFound := true
                break
            }
        }

        if (anchorFound)
        {
            Send, {a Up}
            Sleep, 300
            Send, {q Down}
            Sleep, 400
            Send, {q Up}
            Sleep, 300
            Send, {s Down}
            Sleep, 1000
            Send, {s Up}
            Sleep, 300
            Click, 1148, 94
            Sleep, 1000
            CoordMode, Pixel, Screen
            return
        }
        Sleep, 30
    }
    CoordMode, Pixel, Screen
return

; ============================================================
; TREE CHOPPING, PIXEL, AND OTHER HELPER FUNCTIONS
; ============================================================

ChopTreeX(x1, y1, x2, y2, steps := 12) {
    global STOP

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 15
    }

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x2 + t * (x1 - x2))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 15
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    centerX := Round((x1 + x2) / 2)
    centerY := Round((y1 + y2) / 2)
    needsExtraChop := false

    if (IsGoldTree(centerX, centerY))
        needsExtraChop := true
    else if (IsRainbowTree(centerX, centerY))
        needsExtraChop := true

    if (needsExtraChop)
    {
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x1 + t * (x2 - x1))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 10
        }
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x2 + t * (x1 - x2))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 10
        }

        blueFound := WaitForBluePixel(800)
        if (blueFound)
        {
            WaitForBlueGone(6000)
            Sleep, 50
        }
    }
    
    MountHoverboard()
}

ChopTree(x1, y1, x2, y2, steps := 12) {
    global STOP

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 15
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    centerX := Round((x1 + x2) / 2)
    centerY := Round((y1 + y2) / 2)
    needsExtraChop := false

    if (IsGoldTree(centerX, centerY))
        needsExtraChop := true
    else if (IsRainbowTree(centerX, centerY))
        needsExtraChop := true

    if (needsExtraChop)
    {
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x1 + t * (x2 - x1))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 10
        }

        blueFound := WaitForBluePixel(800)
        if (blueFound)
        {
            WaitForBlueGone(6000)
            Sleep, 50
        }
    }
    
    MountHoverboard()
}

ChopTreeFast(x1, y1, x2, y2, steps := 8) {
    global STOP

    Loop, %steps% {
        if (STOP)
            return
        t := (A_Index - 1) / (steps - 1)
        x := Round(x1 + t * (x2 - x1))
        y := Round(y1 + t * (y2 - y1))
        FastClick(x, y, 1)
        Sleep, 5
    }

    blueFound := WaitForBluePixel(1200)
    if (blueFound)
    {
        WaitForBlueGone(6000)
        Sleep, 50
    }

    centerX := Round((x1 + x2) / 2)
    centerY := Round((y1 + y2) / 2)
    needsExtraChop := false

    if (IsGoldTree(centerX, centerY))
        needsExtraChop := true
    else if (IsRainbowTree(centerX, centerY))
        needsExtraChop := true

    if (needsExtraChop)
    {
        Loop, %steps% {
            if (STOP)
                return
            t := (A_Index - 1) / (steps - 1)
            x := Round(x1 + t * (x2 - x1))
            y := Round(y1 + t * (y2 - y1))
            FastClick(x, y, 1)
            Sleep, 3
        }

        blueFound := WaitForBluePixel(800)
        if (blueFound)
        {
            WaitForBlueGone(6000)
            Sleep, 50
        }
    }
    
    MountHoverboard()
}

WaitForBluePixel(timeoutMs) {
    global STOP
    start := A_TickCount
    while (!STOP && (A_TickCount - start) < timeoutMs) {
        PixelSearch, fx, fy, 390, 702, 415, 736, 0x32AEFD, 15, Fast RGB
        if (ErrorLevel = 0)
            return true
        Sleep, 20
    }
    return false
}

WaitForBlueGone(timeoutMs) {
    global STOP
    start := A_TickCount
    while (!STOP && (A_TickCount - start) < timeoutMs) {
        PixelSearch, fx, fy, 390, 702, 415, 736, 0x32AEFD, 15, Fast RGB
        if (ErrorLevel != 0)
            return true
        Sleep, 50
    }
    return false
}

IsGoldTree(x, y) {
    PixelGetColor, c, %x%, %y%, RGB
    r := (c >> 16) & 0xFF
    g := (c >> 8) & 0xFF
    b := c & 0xFF

    if (r > 200 && g > 200 && b < 120)
        return true
    return false
}

IsRainbowTree(x, y, samples := 3, threshold := 2) {
    colors := []
    Loop, %samples% {
        PixelGetColor, c, %x%, %y%, RGB
        colors.Push(c)
        Sleep, 60
    }

    changes := 0
    Loop, % colors.Length() - 1 {
        c1 := colors[A_Index]
        c2 := colors[A_Index + 1]

        r1 := (c1 >> 16) & 0xFF, g1 := (c1 >> 8) & 0xFF, b1 := c1 & 0xFF
        r2 := (c2 >> 16) & 0xFF, g2 := (c2 >> 8) & 0xFF, b2 := c2 & 0xFF

        diff := Abs(r1 - r2) + Abs(g1 - g2) + Abs(b1 - b2)
        if (diff > 80)
            changes++
    }

    return (changes >= threshold)
}

FastClick(x, y, clicks := 1) {
    global windowWidth, windowHeight

    if (x < 10)
        x := 10
    if (x > windowWidth - 10)
        x := windowWidth - 10
    if (y < 10)
        y := 10
    if (y > windowHeight - 10)
        y := windowHeight - 10

    Click, %x%, %y%, %clicks%
    return true
}

SafeClick(x, y, clicks := 1) {
    global robloxExe, windowWidth, windowHeight

    if (x < 10)
        x := 10
    if (x > windowWidth - 10)
        x := windowWidth - 10
    if (y < 10)
        y := 10
    if (y > windowHeight - 10)
        y := windowHeight - 10

    WinActivate, ahk_exe %robloxExe%
    WinWaitActive, ahk_exe %robloxExe%,, 0.5

    IfWinNotActive, ahk_exe %robloxExe%
    {
        WinActivate, ahk_exe %robloxExe%
        Sleep, 100
    }

    Click, %x%, %y%, %clicks%
    return true
}

MountHoverboard() {
    SendEvent, {q Down}
    Sleep, 400
    SendEvent, {q Up}
    Sleep, 300
}

HideBox(name) {
    n1 := name . "T"
    n2 := name . "B"
    n3 := name . "L"
    n4 := name . "R"
    Gui, %n1%:Destroy
    Gui, %n2%:Destroy
    Gui, %n3%:Destroy
    Gui, %n4%:Destroy
}

DrawBox(name, x, y, w, h, color) {
    WinGetPos, winX, winY,,, ahk_exe RobloxPlayerBeta.exe

    bx := winX + x
    by := winY + y
    border := 2

    n1 := name . "T"
    Gui, %n1%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n1%:Color, %color%
    Gui, %n1%:Show, x%bx% y%by% w%w% h%border% NoActivate

    bottomY := by + h - border
    n2 := name . "B"
    Gui, %n2%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n2%:Color, %color%
    Gui, %n2%:Show, x%bx% y%bottomY% w%w% h%border% NoActivate

    n3 := name . "L"
    Gui, %n3%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n3%:Color, %color%
    Gui, %n3%:Show, x%bx% y%by% w%border% h%h% NoActivate

    rightX := bx + w - border
    n4 := name . "R"
    Gui, %n4%:+AlwaysOnTop -Caption +ToolWindow
    Gui, %n4%:Color, %color%
    Gui, %n4%:Show, x%rightX% y%by% w%border% h%h% NoActivate
}