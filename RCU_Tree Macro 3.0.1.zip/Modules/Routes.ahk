; ============================================================
; ROUTE DEFINITIONS
; Each function contains teleport logic + movement + chop calls
; ============================================================

Route_Spawn() {
    ; Spawn is default — main script handles teleport + mount
    ; So this function starts AFTER both are complete

    ; No Tree - Small movement above to align with the left-sign better.
    ; Send, {w Down}
    ; Sleep, 700
    ; Send, {w Up}
    ; Sleep, 50

    ; TREE #1
    ;Send, {a Down}
    ;Sleep, 900
    ;Send, {a Up}
    ;Sleep, 50
    ;ChopTreeX(885, 184, 203, 368)

    ; TREE #2
    Send, {w Down}
    Sleep, 600
    Send, {w Up}
    Sleep, 50
    ChopTreeX(522, 105, 1132, 798)

    ; TREE #3
    Send, {D Down}
    Sleep, 590
    Send, {D Up}
    Sleep, 50
    Send, {I Down}
    Sleep, 250
    Send, {I Up}
    Sleep, 100
    Send, {Q Down}
    Sleep, 50
    Send, {Q Up}
    Sleep, 50
	ChopTreeX(445, 363, 857, 692)
    Send, {O Down}
    Sleep, 250
    Send, {O Up}
    Sleep, 10

    ; TREE #4
    Send, {W Down}
    Sleep, 700
    Send, {W Up}
    Sleep, 50
    ChopTreeX(885, 184, 203, 368)
	Sleep, 500

    ; TREE #5
    Send, {D Down}
    Sleep, 250
    Send, {D Up}
    Sleep, 50
    Send, {S Down}
    Sleep, 600
    Send, {S Up}
    Sleep, 50
    ChopTreeFast(1125, 98, 1013, 266)

    ; TREE #6
    Send, {D Down}
    Sleep, 600
    Send, {D Up}
    Sleep, 50
    ChopTreeX(1019, 348, 1287, 95)

    ; TREE #7
    Send, {W Down}
    Sleep, 200
    Send, {W Up}
    Sleep, 50
    Send, {D Down}
    Sleep, 1000
    Send, {D Up}
    Sleep, 50
    Send, {S Down}
    Sleep, 400
    Send, {S Up}
    Sleep, 50
    ChopTreeX(565, 685, 1033, 945)

    ; TREE #8
    Send, {S Down}
    Sleep, 500
    Send, {S Up}
    Sleep, 50
    ChopTreeX(565, 685, 1033, 945)

    ; TREE #9
    Send, {A Down}
    Sleep, 600
    Send, {A Up}
    Sleep, 50
    ChopTreeX(517, 706, 847, 934)

    ; TREE #10
    Send, {D Down}
    Sleep, 500
    Send, {D Up}
    Sleep, 50
    ChopTreeX(299, 677, 1179, 905)

    ; TREE #11
    Send, {S Down}
    Sleep, 600
    Send, {S Up}
    Sleep, 50
    ChopTreeFast(194, 393, 675, 759)

    ; TREE #12
    Send, {A Down}
    Sleep, 600
    Send, {A Up}
    Sleep, 50
    ChopTreeX(295, 314, 1078, 821)

	GoSub, SpawnTeleportLoop

    GoSub, CheckRewards

    Send, {W Down}
    Sleep, 200
    Send, {W Up}
    Sleep, 300
	
    Send, {A Down}
    Sleep, 600
    Send, {A Up}
    Sleep, 300

    Send, {W Down}
    Sleep, 200
    Send, {W Up}
    Sleep, 300

    ; Click tree (same as FindSpawnAnchor)
    ChopTreeX(143, 306, 547, 700)

}

Route_Desert() {
    TeleportTo("Desert")
    MountHoverboard()
    
    ; TODO: movement + chop calls for Desert
}

Route_Nuclear() {
    TeleportTo("Nuclear")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Atlantis() {
    TeleportTo("Atlantis")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Kingdom() {
    TeleportTo("Kingdom")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Cave() {
    TeleportTo("Cave")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Volcano() {
    TeleportTo("Volcano")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Heaven() {
    TeleportTo("Heaven")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Magic() {
    TeleportTo("Magic")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Circus() {
    TeleportTo("Circus")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Jungle() {
    TeleportTo("Jungle")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Steampunk() {
    TeleportTo("Steampunk")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

Route_Sakura() {
    TeleportTo("Sakura")
    MountHoverboard()
    
    ; TODO: movement + chop calls
}

; ============================================================
; TELEPORT HELPER
; Types area name into search box, then clicks teleport button
; ============================================================
TeleportTo(areaName) {
    ; Open teleport menu
    SendEvent, t
    Sleep, 1500

    ; Temporarily switch to Client coords for search box click
    CoordMode, Mouse, Client
    
    ; Click search box - using Client coordinates
    Click, 791, 305, 0  ; Move to search box
    Sleep, 50
    Click, 791, 305, 5  ; Click 5 times rapidly
    Sleep, 500
    
    ; Switch back to Window coords
    CoordMode, Mouse, Window

    ; Type the area name using SendInput explicitly (no SendMode change)
    SendInput, {Text}%areaName%
    Sleep, 75

    ; Click away from search box to deselect (Window coords)
    Click, 260, 800
    Sleep, 200

    ; Click teleport button - use Click command (inherits SendMode Event)
    Click, 812, 490
    Sleep, 100
    Click, 812, 490
    Sleep, 100
    Click, 812, 491
    Sleep, 100
    Click, 812, 491
    Sleep, 100
    Click, 812, 490
    Sleep, 2000
}