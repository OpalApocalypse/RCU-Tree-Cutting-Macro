AlignMushroom:
    mushroomFound := false

    ; Check for multiple arrow color variants (red, dusty tan, etc.)
    PixelSearch, px, py, 658, 181, 815, 281, 0xFF1C00, 96, Fast RGB  ; Bright red
    if (ErrorLevel = 0)
        mushroomFound := true
    
    if (!mushroomFound)
    {
        PixelSearch, px, py, 658, 181, 815, 281, 0xF9CA8E, 30, Fast RGB  ; Dusty tan
        if (ErrorLevel = 0)
            mushroomFound := true
    }

    if (!mushroomFound)
    {
        ALT_ROUTE := true

        Send, {Left Down}
        Sleep, 150
        Send, {Left Up}
        Sleep, 80

        Loop, 25 {
            anomalyFound := false
            Loop, Files, %A_ScriptDir%\Resources\*Anomaly_10x10.*
            {
                ImageSearch, mx, my, 884, 330, 964, 400, *50 %A_LoopFileFullPath%
                if (ErrorLevel = 0)
                {
                    anomalyFound := true
                    break
                }
            }
            if (anomalyFound)
            {
                Send, {Left Down}
                Sleep, 10
                Send, {Left Up}
                Sleep, 60
                break
            }

            Send, {Left Down}
            Sleep, 10
            Send, {Left Up}
            Sleep, 60
        }
        Send, {Left Up}
        Sleep, 10
    }
    else
    {
        ALT_ROUTE := false
    }
return