﻿RedeemRewards:
    PixelSearch, rx, ry, 1275, 456, 1298, 480, 0xFF444F, 15, Fast RGB

    if (ErrorLevel = 0)
    {
        SafeClick(1212, 475)
        Sleep, 500

        SafeClick(425, 414)
        Sleep, 200
        SafeClick(578, 414)
        Sleep, 200
        SafeClick(726, 414)
        Sleep, 200
        SafeClick(885, 447)
        Sleep, 200

        SafeClick(429, 525)
        Sleep, 200
        SafeClick(577, 525)
        Sleep, 200
        SafeClick(727, 525)
        Sleep, 200
        SafeClick(877, 525)
        Sleep, 200

        SafeClick(425, 630)
        Sleep, 200
        SafeClick(577, 630)
        Sleep, 200
        SafeClick(727, 630)
        Sleep, 200
        SafeClick(877, 630)
        Sleep, 500

        SafeClick(955, 308)
        Sleep, 100
        SafeClick(955, 308)
        Sleep, 100
        SafeClick(955, 308)
        Sleep, 300
    }
return